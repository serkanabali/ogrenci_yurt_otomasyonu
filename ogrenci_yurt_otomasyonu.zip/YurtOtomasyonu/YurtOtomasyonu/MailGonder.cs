﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class MailGonder : Form
    {
        public MailGonder()
        {
            InitializeComponent();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=projeotomasyon;Integrated Security=True";

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.CommandText = "UPDATE Ogrenciler SET Mesaj = @yeniMesaj WHERE AdSoyad = @degisecekAdSoyad";

            komut.Parameters.AddWithValue("@yeniMesaj", textBox2.Text);

            komut.Parameters.AddWithValue("@degisecekAdSoyad", textBox1.Text);
            komut.Connection = baglanti;

            komut.ExecuteNonQuery();

            baglanti.Close();

            MessageBox.Show("Mesajınız Gönderildi.");
        }

        private void MailGonder_FormClosing(object sender, FormClosingEventArgs e)
        {
            OgrenciDogrula f = new OgrenciDogrula();
            f.Show();
        }

        //Ödeme
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.CommandText = "UPDATE Ogrenciler SET Ucret = @yeniOdeme WHERE AdSoyad = @degisecekAd";

            komut.Parameters.AddWithValue("@yeniOdeme", textBox3.Text);

            komut.Parameters.AddWithValue("@degisecekAd", textBox1.Text);
            komut.Connection = baglanti;

            komut.ExecuteNonQuery();

            baglanti.Close();

            MessageBox.Show("Güncelleme Başarılı");
        }

        private void btn_cikis_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.CommandText = "UPDATE Ogrenciler SET Cikis = @yeniCikis WHERE AdSoyad = @degisecekAd";

            komut.Parameters.AddWithValue("@yeniCikis", girisDate.Value);

            komut.Parameters.AddWithValue("@degisecekAd", textBox1.Text);
            komut.Connection = baglanti;

            komut.ExecuteNonQuery();

            baglanti.Close();

            MessageBox.Show("Güncelleme Başarılı");
        }

        private void btn_giris_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.CommandText = "UPDATE Ogrenciler SET Giris = @yeniGiris WHERE AdSoyad = @degisecekAd";

            komut.Parameters.AddWithValue("@yeniGiris", girisDate.Value);

            komut.Parameters.AddWithValue("@degisecekAd", textBox1.Text);
            komut.Connection = baglanti;

            komut.ExecuteNonQuery();

            baglanti.Close();

            MessageBox.Show("Güncelleme Başarılı");
        }
    }
}
