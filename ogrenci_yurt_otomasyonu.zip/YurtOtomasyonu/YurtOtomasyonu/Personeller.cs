﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class Personeller : Form
    {
        public Personeller()
        {
            InitializeComponent();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=projeotomasyon;Integrated Security=True";

        private void btn_veriEkle_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.Connection = baglanti;
            komut.CommandText = "INSERT INTO Personeller (PersonelAdSoyad, PersonelKulAdi, PersonelSifre) VALUES (@peradsoyad, @perkuladi, @persifre)";

            //Parametrelerimize Form üzerinde ki kontrollerden girilen verileri aktarıyoruz.
            komut.Parameters.AddWithValue("@peradsoyad", txt_isim.Text);
            komut.Parameters.AddWithValue("@perkuladi", txt_PerKulAdi.Text);
            komut.Parameters.AddWithValue("@persifre", txt_PerSifre.Text);

            //Veritabanında değişiklik yapacak komut işlemi bu satırda gerçekleşiyor.
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Yeni kayıt yapıldı");
        }

        private void btn_listele_Click(object sender, EventArgs e)
        {
            SqlDataAdapter kopru = new SqlDataAdapter("SELECT * FROM Personeller", baglantiDizesi);
            DataTable tablo = new DataTable();
            kopru.Fill(tablo);
            dataGridView1.DataSource = tablo;
        }

        private void Personeller_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }
    }
}
