﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class IzınIste : Form
    {
        public IzınIste()
        {
            InitializeComponent();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=projeotomasyon;Integrated Security=True";

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.CommandText = "UPDATE Personeller SET Izin = @yeniIzin, CikisTarihi = @yeniCikis, DonusTarihi = @yeniDonus WHERE PersonelAdSoyad = @degisecekAdSoyad";

            komut.Parameters.AddWithValue("@yeniIzin", textBox2.Text);
            komut.Parameters.AddWithValue("@yeniCikis", cikisTar.Value);
            komut.Parameters.AddWithValue("@yeniDonus", donusTar.Value);

            komut.Parameters.AddWithValue("@degisecekAdSoyad", textBox1.Text);
            komut.Connection = baglanti;

            komut.ExecuteNonQuery();

            baglanti.Close();

            MessageBox.Show("İzin Sebebi Bildirildi.");
        }

        private void IzınIste_FormClosing(object sender, FormClosingEventArgs e)
        {
            PersonelDogrula f = new PersonelDogrula();
            f.Show();
        }
    }
}
