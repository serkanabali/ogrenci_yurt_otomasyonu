﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class Oda : Form
    {
        public Oda()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.BackColor == Color.Lime)
            {
                button1.BackColor = Color.Red;
            }
            else if (button1.BackColor == Color.Red)
            {
                button1.BackColor = Color.Lime;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.BackColor == Color.Lime)
            {
                button2.BackColor = Color.Red;
            }
            else if (button2.BackColor == Color.Red)
            {
                button2.BackColor = Color.Lime;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button3.BackColor == Color.Lime)
            {
                button3.BackColor = Color.Red;
            }
            else if (button3.BackColor == Color.Red)
            {
                button3.BackColor = Color.Lime;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.BackColor == Color.Lime)
            {
                button4.BackColor = Color.Red;
            }
            else if (button4.BackColor == Color.Red)
            {
                button4.BackColor = Color.Lime;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.BackColor == Color.Lime)
            {
                button5.BackColor = Color.Red;
            }
            else if (button5.BackColor == Color.Red)
            {
                button5.BackColor = Color.Lime;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (button6.BackColor == Color.Lime)
            {
                button6.BackColor = Color.Red;
            }
            else if (button6.BackColor == Color.Red)
            {
                button6.BackColor = Color.Lime;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (button7.BackColor == Color.Lime)
            {
                button7.BackColor = Color.Red;
            }
            else if (button7.BackColor == Color.Red)
            {
                button7.BackColor = Color.Lime;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (button8.BackColor == Color.Lime)
            {
                button8.BackColor = Color.Red;
            }
            else if (button8.BackColor == Color.Red)
            {
                button8.BackColor = Color.Lime;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (button9.BackColor == Color.Lime)
            {
                button9.BackColor = Color.Red;
            }
            else if (button9.BackColor == Color.Red)
            {
                button9.BackColor = Color.Lime;
            }
        }

        private void Oda_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }
    }
}
