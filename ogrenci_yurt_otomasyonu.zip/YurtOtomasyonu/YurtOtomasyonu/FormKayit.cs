﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class FormKayit : Form
    {
        public FormKayit()
        {
            InitializeComponent();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=projeotomasyon;Integrated Security=True";

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.Connection = baglanti;
            komut.CommandText = "INSERT INTO Ogrenciler (No, AdSoyad, Tc, Tel, Dogum, Kayit, OgrKulAdi, OgrSifre) VALUES (@no, @adsoyad, @tc, @tel, @dogum, @kayit, @ogrkuladi, @ogrsifre)";

            //Parametrelerimize Form üzerinde ki kontrollerden girilen verileri aktarıyoruz.
            komut.Parameters.AddWithValue("@no", txt_no.Text);
            komut.Parameters.AddWithValue("@adsoyad", textBoxAdSoyad.Text);
            komut.Parameters.AddWithValue("@tc", txt_tc.Text);
            komut.Parameters.AddWithValue("@tel", text_tel.Text);
            komut.Parameters.AddWithValue("@dogum", dogumTarih.Value);
            komut.Parameters.AddWithValue("@kayit", kayitTarih.Value);
            komut.Parameters.AddWithValue("@ogrkuladi", txt_OgrKulAdi.Text);
            komut.Parameters.AddWithValue("@ogrsifre", txt_OgrSifre.Text);

            //Veritabanında değişiklik yapacak komut işlemi bu satırda gerçekleşiyor.
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Yeni kayıt yapıldı");
        }

        private void FormKayit_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }
    }
}
