﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Kayit
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            FormKayit f = new FormKayit();
            f.Show();
            this.Hide();
        }

        //Guncelle
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            FormGuncelle f = new FormGuncelle();
            f.Show();
            this.Hide();
        }

        //Ogrenciler
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            FormOgrenciler f = new FormOgrenciler();
            f.Show();
            this.Hide();
        }

        //Silme
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            FormSilme f = new FormSilme();
            f.Show();
            this.Hide();
        }

        //Oda
        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Oda f = new Oda();
            f.Show();
            this.Hide();
        }

        //Personel
        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Personeller f = new Personeller();
            f.Show();
            this.Hide();
        }

        //Cikis
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DialogResult sonuc;
            sonuc = MessageBox.Show("Bu Menüyü Kapatmak İstediğinizden Emin Misiniz?", "Uyarı!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (sonuc == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            YoneticiDogrula f = new YoneticiDogrula();
            f.Show();
            this.Hide();
        }
    }
}
