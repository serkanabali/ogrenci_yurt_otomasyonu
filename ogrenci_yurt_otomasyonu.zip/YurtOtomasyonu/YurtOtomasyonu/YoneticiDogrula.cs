﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class YoneticiDogrula : Form
    {
        public YoneticiDogrula()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Giris f = new Giris();
            f.Show();
            this.Hide();
        }

        private void YoneticiDogrula_FormClosing(object sender, FormClosingEventArgs e)
        {
            Giris f = new Giris();
            f.Show();
            this.Hide();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=projeotomasyon;Integrated Security=True";
        SqlConnection baglanti;

        private void button2_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(textBox2.Text)
                || String.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Kullanıcı adı ve şifre boş bırakılamaz");
            }
            else
            {
                baglanti.Open();

                SqlCommand komut = new SqlCommand();
                komut.Connection = baglanti;
                komut.CommandText = "select * from Yonetici where kullaniciAdi=@kullanici";
                komut.Parameters.AddWithValue("@kullanici", textBox1.Text);

                SqlDataReader okuyucu = komut.ExecuteReader();

                if (okuyucu.Read() == true)
                {
                    if (okuyucu["kullaniciAdi"].ToString() == textBox1.Text
                        && okuyucu["sifre"].ToString() == textBox2.Text)
                    {
                        Form1 f = new Form1();
                        f.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Kullanıcı adı veya şifre yanlış.");
                    }
                }
                else
                {
                    MessageBox.Show("Kullanıcı adı veya şifre yanlış.");
                }

                baglanti.Close();
            }
        }

        private void YoneticiDogrula_Load(object sender, EventArgs e)
        {
            baglanti = new SqlConnection(baglantiDizesi);
            textBox2.PasswordChar = '*';
        }
    }
}
