﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class FormOgrenciler : Form
    {
        public FormOgrenciler()
        {
            InitializeComponent();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=projeotomasyon;Integrated Security=True";

        private void buttonListele_Click(object sender, EventArgs e)
        {
            SqlDataAdapter kopru = new SqlDataAdapter("SELECT * FROM Ogrenciler", baglantiDizesi);
            DataTable tablo = new DataTable();
            kopru.Fill(tablo);
            dataGridView1.DataSource = tablo;
        }

        private void FormOgrenciler_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }
    }
}
