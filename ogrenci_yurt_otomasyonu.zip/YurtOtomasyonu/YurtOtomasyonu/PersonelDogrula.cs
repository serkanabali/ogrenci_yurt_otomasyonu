﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class PersonelDogrula : Form
    {
        public PersonelDogrula()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Giris f = new Giris();
            f.Show();
            this.Hide();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=projeotomasyon;Integrated Security=True";
        SqlConnection baglanti;

        private void button2_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(textBox2.Text)
                || String.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Kullanıcı adı ve şifre boş bırakılamaz");
            }
            else
            {
                baglanti.Open();

                SqlCommand komut = new SqlCommand();
                komut.Connection = baglanti;
                komut.CommandText = "select * from Personeller where PersonelKulAdi=@kullanici";
                komut.Parameters.AddWithValue("@kullanici", textBox1.Text);

                SqlDataReader okuyucu = komut.ExecuteReader();

                if (okuyucu.Read() == true)
                {
                    if (okuyucu["PersonelKulAdi"].ToString() == textBox1.Text
                        && okuyucu["PersonelSifre"].ToString() == textBox2.Text)
                    {
                        IzınIste f = new IzınIste();
                        f.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Kullanıcı adı veya şifre yanlış.");
                    }
                }
                else
                {
                    MessageBox.Show("Kullanıcı adı veya şifre yanlış.");
                }

                baglanti.Close();
            }
        }

        private void PersonelDogrula_Load(object sender, EventArgs e)
        {
            baglanti = new SqlConnection(baglantiDizesi);
            textBox2.PasswordChar = '*';
        }

        private void PersonelDogrula_FormClosing(object sender, FormClosingEventArgs e)
        {
            Giris f = new Giris();
            f.Show();
            this.Hide();
        }
    }
}
