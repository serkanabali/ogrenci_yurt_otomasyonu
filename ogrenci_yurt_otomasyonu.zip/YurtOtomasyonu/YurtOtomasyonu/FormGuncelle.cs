﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YurtOtomasyonu
{
    public partial class FormGuncelle : Form
    {
        public FormGuncelle()
        {
            InitializeComponent();
        }

        string baglantiDizesi = "Data Source=LAPTOP-SERKAN;Initial Catalog=projeotomasyon;Integrated Security=True";

        private void btn_getir_Click(object sender, EventArgs e)
        {
            SqlDataAdapter kopru = new SqlDataAdapter("SELECT * FROM Ogrenciler", baglantiDizesi);
            DataTable tablo = new DataTable();
            kopru.Fill(tablo);
            dataGridView1.DataSource = tablo;
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection(baglantiDizesi);
            baglanti.Open();

            SqlCommand komut = new SqlCommand();
            komut.CommandText = "UPDATE Ogrenciler SET No = @yeniNo, AdSoyad = @yeniAdSoyad, Tel = @yeniTel, OgrKulAdi = @yeniOgrKulAdi, OgrSifre = @yeniOgrSifre WHERE ID = @degisecekID";

            komut.Parameters.AddWithValue("@yeniNo", txt_no.Text);
            komut.Parameters.AddWithValue("@yeniAdSoyad", textBoxAdSoyad.Text);
            komut.Parameters.AddWithValue("@yeniTel", txt_tel.Text);
            komut.Parameters.AddWithValue("@yeniOgrKulAdi", txt_kuladi.Text);
            komut.Parameters.AddWithValue("@yeniOgrSifre", txt_sifre.Text);

            komut.Parameters.AddWithValue("@degisecekID", txt_id.Text);
            komut.Connection = baglanti;

            komut.ExecuteNonQuery();

            baglanti.Close();

            MessageBox.Show("Güncelleme Başarılı");
        }

        private void FormGuncelle_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }

        private void FormGuncelle_Load(object sender, EventArgs e)
        {
            txt_id.ReadOnly = true;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Cell Click olayı hücrenin herhangi bir noktasına tıklandığı zaman çalışır.
            txt_id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txt_no.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            textBoxAdSoyad.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txt_tel.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txt_kuladi.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txt_sifre.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
        }
    }
}
